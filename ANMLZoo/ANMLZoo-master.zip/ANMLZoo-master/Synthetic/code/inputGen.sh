#!/bin/bash

echo -n $
for(( i=0; i<${1}; i++ ))
do
    echo -n a
done
